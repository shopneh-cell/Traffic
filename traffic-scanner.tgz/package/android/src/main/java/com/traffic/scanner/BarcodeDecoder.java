package com.traffic.scanner;

import androidx.camera.core.ImageProxy;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.GlobalHistogramBinarizer;
import com.google.zxing.common.HybridBinarizer;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * دیکدر بارکد روی فریم‌های دوربین با ZXing Core. کاملاً آفلاین و بدون Play Services.
 * تمام منطق تشخیص اینجاست، نه داخل Activity یا UI.
 */
final class BarcodeDecoder {
    /** فرمت‌های موردنیاز؛ ترتیب مهم است و EAN برای لوازم‌التحریر اولویت دارد. */
    private static final List<BarcodeFormat> FORMATS = Arrays.asList(
            BarcodeFormat.EAN_13, BarcodeFormat.EAN_8,
            BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
            BarcodeFormat.CODE_128, BarcodeFormat.CODE_39,
            BarcodeFormat.ITF, BarcodeFormat.CODABAR,
            BarcodeFormat.QR_CODE);

    private final MultiFormatReader reader = new MultiFormatReader();
    private byte[] yBuf;
    private byte[] rBuf;
    private byte[] tBuf;
    private int frame = 0;

    BarcodeDecoder() {
        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, FORMATS);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        reader.setHints(hints);
    }

    /** نتیجه‌ی تشخیص در این فریم، یا null. فریم را خودش نمی‌بندد. */
    Result decode(ImageProxy img) {
        ImageProxy.PlaneProxy plane = img.getPlanes()[0];
        ByteBuffer buf = plane.getBuffer();
        int rowStride = plane.getRowStride();
        int w = img.getWidth();
        int h = img.getHeight();
        int rot = img.getImageInfo().getRotationDegrees();
        int n = w * h;
        if (yBuf == null || yBuf.length != n) {
            yBuf = new byte[n];
            rBuf = new byte[n];
            tBuf = new byte[n];
        }
        for (int r = 0; r < h; r++) {
            buf.position(r * rowStride);
            buf.get(yBuf, r * w, w);
        }
        byte[] src;
        int sw;
        int sh;
        if (rot == 90 || rot == 270) {
            rotate(yBuf, rBuf, w, h, rot);
            src = rBuf;
            sw = h;
            sh = w;
        } else if (rot == 180) {
            for (int i = 0; i < n; i++) {
                rBuf[i] = yBuf[n - 1 - i];
            }
            src = rBuf;
            sw = w;
            sh = h;
        } else {
            src = yBuf;
            sw = w;
            sh = h;
        }
        // در هر فریم یکی از دو روش روشنایی (Hybrid یا Global) امتحان می‌شود تا دقت و سرعت متعادل بماند.
        Result res = decodeRegion(src, sw, sh, frame % 2 == 0);
        if (res == null) {
            // بارکد افقی یا عمودی: یک بار روی تصویر ۹۰ درجه‌چرخیده هم امتحان می‌شود.
            rotate(src, tBuf, sw, sh, 90);
            res = decodeRegion(tBuf, sh, sw, frame % 2 == 1);
        }
        frame++;
        return res;
    }

    /** فقط ناحیه‌ی مرکزی (همان کادر راهنما) تحلیل می‌شود؛ هم سریع‌تر است و هم کمتر اشتباه می‌کند. */
    private Result decodeRegion(byte[] data, int dw, int dh, boolean hybrid) {
        int left = (int) (dw * 0.07f);
        int top = (int) (dh * 0.30f);
        int cw = dw - 2 * left;
        int ch = (int) (dh * 0.40f);
        try {
            PlanarYUVLuminanceSource src = new PlanarYUVLuminanceSource(data, dw, dh, left, top, cw, ch, false);
            BinaryBitmap bmp = new BinaryBitmap(hybrid ? new HybridBinarizer(src) : new GlobalHistogramBinarizer(src));
            return reader.decodeWithState(bmp);
        } catch (ReaderException e) {
            return null;
        } finally {
            reader.reset();
        }
    }

    private static void rotate(byte[] s, byte[] d, int w, int h, int rot) {
        if (rot == 90) {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) {
                    d[x * h + (h - 1 - y)] = s[ro + x];
                }
            }
        } else {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) {
                    d[(w - 1 - x) * h + y] = s[ro + x];
                }
            }
        }
    }
}

package com.traffic.scanner;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.Queue;

class LiveAnalyzer implements ImageAnalysis.Analyzer {
    private final Queue<String[]> out;
    private final MultiFormatReader reader = new MultiFormatReader();
    private byte[] yBuf, rBuf, tBuf;
    private String last = "";
    private long lastT = 0;
    private int frame = 0;

    LiveAnalyzer(Queue<String[]> out) {
        this.out = out;
        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
                BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.CODE_93, BarcodeFormat.ITF,
                BarcodeFormat.CODABAR, BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX));
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        reader.setHints(hints);
    }

    @Override
    public void analyze(@NonNull ImageProxy img) {
        try {
            ImageProxy.PlaneProxy pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rs = pl.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();
            int rot = img.getImageInfo().getRotationDegrees();
            if (yBuf == null || yBuf.length != w * h) {
                yBuf = new byte[w * h];
                rBuf = new byte[w * h];
                tBuf = new byte[w * h];
            }
            for (int r = 0; r < h; r++) {
                buf.position(r * rs);
                buf.get(yBuf, r * w, w);
            }
            byte[] src = yBuf;
            int sw = w, sh = h;
            if (rot == 90 || rot == 270) {
                rotate(yBuf, rBuf, w, h, rot);
                src = rBuf;
                sw = h;
                sh = w;
            } else if (rot == 180) {
                int n = w * h;
                for (int i = 0; i < n; i++) rBuf[i] = yBuf[n - 1 - i];
                src = rBuf;
            }
            Result res = decode(src, sw, sh);
            if (res == null && (frame++ % 3 == 2)) {
                rotate(src, tBuf, sw, sh, 90);
                res = decode(tBuf, sh, sw);
            }
            if (res != null && res.getText() != null && !res.getText().isEmpty()) {
                String v = res.getText();
                long now = System.currentTimeMillis();
                if (v.equals(last) && now - lastT < 1500) {
                    if (out.size() < 5) out.offer(new String[]{v, res.getBarcodeFormat().name()});
                    last = "";
                } else {
                    last = v;
                    lastT = now;
                }
            }
        } catch (Exception ignored) {
        } finally {
            img.close();
        }
    }

    private Result decode(byte[] d, int dw, int dh) {
        int l = (int) (dw * 0.05), t = (int) (dh * 0.2), cw = dw - 2 * l, ch = (int) (dh * 0.6);
        try {
            PlanarYUVLuminanceSource s = new PlanarYUVLuminanceSource(d, dw, dh, l, t, cw, ch, false);
            return reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(s)));
        } catch (ReaderException e) {
            return null;
        } finally {
            reader.reset();
        }
    }

    private static void rotate(byte[] s, byte[] d, int w, int h, int rot) {
        if (rot == 90) {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) d[x * h + (h - 1 - y)] = s[ro + x];
            }
        } else {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) d[(w - 1 - x) * h + y] = s[ro + x];
            }
        }
    }
}

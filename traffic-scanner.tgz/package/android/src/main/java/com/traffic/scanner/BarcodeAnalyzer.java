package com.traffic.scanner;

import androidx.annotation.NonNull;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import com.google.zxing.Result;

/**
 * تحلیل‌گر فریم‌های دوربین. تشخیص با BarcodeDecoder، و تأیید نهایی:
 * همان مقدار باید در دو فریم پشت‌سرهم و نزدیک به هم دیده شود تا خطای تصادفی حذف شود.
 */
public final class BarcodeAnalyzer implements ImageAnalysis.Analyzer {

    public interface Listener {
        void onBarcode(String value, String format);
    }

    private static final long CONFIRM_WINDOW_MS = 1500L;

    private final BarcodeDecoder decoder = new BarcodeDecoder();
    private final Listener listener;
    private volatile boolean paused = false;
    private String lastValue = "";
    private long lastAt = 0L;

    public BarcodeAnalyzer(Listener listener) {
        this.listener = listener;
    }

    /** مکث موقت پس از تشخیص (تا یک بارکد چند بار ثبت نشود). */
    public void setPaused(boolean value) {
        paused = value;
        lastValue = "";
        lastAt = 0L;
    }

    @Override
    public void analyze(@NonNull ImageProxy image) {
        try {
            if (paused) {
                return;
            }
            Result result = decoder.decode(image);
            if (result == null) {
                return;
            }
            String value = result.getText();
            if (value == null || value.isEmpty()) {
                return;
            }
            long now = System.currentTimeMillis();
            if (value.equals(lastValue) && now - lastAt < CONFIRM_WINDOW_MS) {
                lastValue = "";
                lastAt = 0L;
                listener.onBarcode(value, result.getBarcodeFormat().name());
            } else {
                lastValue = value;
                lastAt = now;
            }
        } catch (Exception ignored) {
            // یک فریم خراب نباید کل تحلیل را متوقف کند
        } finally {
            image.close();
        }
    }
}

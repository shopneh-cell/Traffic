package com.traffic.scanner;

import android.Manifest;
import android.app.Activity;
import android.content.ContentUris;
import android.database.Cursor;
import com.getcapacitor.JSArray;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.util.Base64;
import java.io.FileOutputStream;
import java.io.OutputStream;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Size;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.activity.result.ActivityResult;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.Preview;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "TrafficScanner", permissions = {@Permission(strings = {Manifest.permission.CAMERA}, alias = "camera")})
public class TrafficScannerPlugin extends Plugin {
    private final Queue<String[]> queue = new ConcurrentLinkedQueue<>();
    private ExecutorService exec;
    private ProcessCameraProvider provider;
    private PreviewView pv;
    private Camera cam;
    private ToneGenerator tone;
    private static volatile boolean locked = true;
    private BroadcastReceiver rcv;

    @Override
    public void load() {
        exec = Executors.newSingleThreadExecutor();
        locked = true;
        rcv = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                locked = true;
            }
        };
        ContextCompat.registerReceiver(getContext(), rcv, new IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    @Override
    protected void handleOnDestroy() {
        if (exec != null) exec.shutdown();
        try {
            if (rcv != null) getContext().unregisterReceiver(rcv);
        } catch (Exception ignored) {
        }
    }

    @PluginMethod
    public void scan(PluginCall call) {
        Intent i = new Intent(getContext(), ScannerActivity.class);
        startActivityForResult(call, i, "onScanResult");
    }

    @ActivityCallback
    private void onScanResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent d = result.getData();
        if (result.getResultCode() == Activity.RESULT_OK && d != null) {
            JSObject o = new JSObject();
            o.put("value", d.getStringExtra("value"));
            o.put("format", d.getStringExtra("format"));
            call.resolve(o);
        } else {
            call.reject("canceled");
        }
    }

    @PluginMethod
    public void start(PluginCall call) {
        if (getPermissionState("camera") != PermissionState.GRANTED) {
            requestPermissionForAlias("camera", call, "permResult");
            return;
        }
        doStart(call);
    }

    @PermissionCallback
    private void permResult(PluginCall call) {
        if (getPermissionState("camera") == PermissionState.GRANTED) doStart(call);
        else call.reject("camera permission denied");
    }

    private static int px(PluginCall c, String k, float d) {
        Double v = c.getDouble(k, 0.0);
        return Math.round((v == null ? 0f : v.floatValue()) * d);
    }

    private void doStart(final PluginCall call) {
        final float d = getActivity().getResources().getDisplayMetrics().density;
        final int x = px(call, "x", d), y = px(call, "y", d), w = px(call, "width", d), h = px(call, "height", d);
        getActivity().runOnUiThread(() -> {
            try {
                stopInternal();
                pv = new PreviewView(getContext());
                pv.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
                FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h, Gravity.TOP | Gravity.LEFT);
                lp.leftMargin = x;
                lp.topMargin = y;
                getActivity().addContentView(pv, lp);
                final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(getContext());
                f.addListener(() -> {
                    try {
                        provider = f.get();
                        Preview pr = new Preview.Builder().build();
                        pr.setSurfaceProvider(pv.getSurfaceProvider());
                        ImageAnalysis ia = new ImageAnalysis.Builder()
                                .setResolutionSelector(new ResolutionSelector.Builder()
                                        .setResolutionStrategy(new ResolutionStrategy(new Size(1920, 1080),
                                                ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                                        .build())
                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                .build();
                        ia.setAnalyzer(exec, new LiveAnalyzer(queue));
                        provider.unbindAll();
                        cam = provider.bindToLifecycle((LifecycleOwner) getActivity(), CameraSelector.DEFAULT_BACK_CAMERA, pr, ia);
                        JSObject o = new JSObject();
                        o.put("hasTorch", cam.getCameraInfo().hasFlashUnit());
                        call.resolve(o);
                    } catch (Exception e) {
                        call.reject("camera: " + e.getMessage());
                    }
                }, ContextCompat.getMainExecutor(getContext()));
            } catch (Exception e) {
                call.reject("camera: " + e.getMessage());
            }
        });
    }

    private void stopInternal() {
        if (provider != null) provider.unbindAll();
        if (pv != null && pv.getParent() instanceof ViewGroup) ((ViewGroup) pv.getParent()).removeView(pv);
        pv = null;
        cam = null;
        queue.clear();
    }

    @PluginMethod
    public void stop(final PluginCall call) {
        getActivity().runOnUiThread(() -> {
            stopInternal();
            call.resolve();
        });
    }

    @PluginMethod
    public void poll(PluginCall call) {
        JSObject o = new JSObject();
        String[] it = queue.poll();
        if (it != null) {
            o.put("value", it[0]);
            o.put("format", it[1]);
        }
        call.resolve(o);
    }

    @PluginMethod
    public void torch(final PluginCall call) {
        final boolean on = Boolean.TRUE.equals(call.getBoolean("on", false));
        getActivity().runOnUiThread(() -> {
            if (cam != null) cam.getCameraControl().enableTorch(on);
            call.resolve();
        });
    }

    @SuppressWarnings("deprecation")
    @PluginMethod
    public void beep(PluginCall call) {
        try {
            if (tone == null) tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 90);
            tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
            Vibrator vb = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
            if (vb != null) {
                if (Build.VERSION.SDK_INT >= 26) vb.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE));
                else vb.vibrate(60);
            }
        } catch (Exception ignored) {
        }
        call.resolve();
    }

    @PluginMethod
    public void lockState(PluginCall call) {
        JSObject o = new JSObject();
        o.put("locked", locked);
        call.resolve(o);
    }

    @PluginMethod
    public void markAuth(PluginCall call) {
        locked = false;
        call.resolve();
    }

    @PluginMethod
    public void bioAvailable(PluginCall call) {
        int r = BiometricManager.from(getContext()).canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.BIOMETRIC_STRONG);
        JSObject o = new JSObject();
        o.put("ok", r == BiometricManager.BIOMETRIC_SUCCESS);
        call.resolve(o);
    }

    @PluginMethod
    public void bioAuth(final PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try {
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                        .setTitle("ورود به ترافیک")
                        .setSubtitle("انگشت خود را روی حسگر بگذارید")
                        .setNegativeButtonText("ورود با رمز")
                        .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK | BiometricManager.Authenticators.BIOMETRIC_STRONG)
                        .build();
                BiometricPrompt bp = new BiometricPrompt(getActivity(), ContextCompat.getMainExecutor(getContext()),
                        new BiometricPrompt.AuthenticationCallback() {
                            @Override
                            public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                                call.resolve();
                            }

                            @Override
                            public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                                call.reject(String.valueOf(msg));
                            }
                        });
                bp.authenticate(info);
            } catch (Exception e) {
                call.reject("bio: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void saveDownload(PluginCall call) {
        final byte[] bytes = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
        final String name = call.getString("name", "file");
        final String mime = call.getString("mime", "application/octet-stream");
        if (bytes.length == 0) {
            call.reject("empty");
            return;
        }
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("unsupported");
            return;
        }
        ContentResolver cr = getContext().getContentResolver();
        Uri u = null;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Traffic");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (u == null) {
                call.reject("insert failed");
                return;
            }
            try (OutputStream o = cr.openOutputStream(u)) {
                o.write(bytes);
            }
            long sz;
            try (ParcelFileDescriptor p = cr.openFileDescriptor(u, "r")) {
                sz = p.getStatSize();
            }
            if (sz != bytes.length) {
                cr.delete(u, null, null);
                call.reject("size mismatch");
                return;
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, done, null, null);
            JSObject r = new JSObject();
            r.put("size", sz);
            r.put("path", "Download/Traffic/" + name);
            call.resolve(r);
        } catch (Exception e) {
            try {
                if (u != null) cr.delete(u, null, null);
            } catch (Exception ignored) {
            }
            call.reject("save: " + e.getMessage());
        }
    }

    @PluginMethod
    public void printPdf(final PluginCall call) {
        final String data = call.getString("data", "");
        final String name = call.getString("name", "Invoice");
        final boolean a5 = "A5".equals(call.getString("size", "A4"));
        getActivity().runOnUiThread(() -> {
            try {
                final byte[] bytes = Base64.decode(data, Base64.DEFAULT);
                PrintManager pm = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                PrintAttributes attrs = new PrintAttributes.Builder()
                        .setMediaSize(a5 ? PrintAttributes.MediaSize.ISO_A5 : PrintAttributes.MediaSize.ISO_A4)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();
                pm.print(name, new PrintDocumentAdapter() {
                    @Override
                    public void onLayout(PrintAttributes oldA, PrintAttributes newA, CancellationSignal cs, LayoutResultCallback cb, Bundle extras) {
                        if (cs.isCanceled()) {
                            cb.onLayoutCancelled();
                            return;
                        }
                        cb.onLayoutFinished(new PrintDocumentInfo.Builder(name + ".pdf")
                                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                                .build(), true);
                    }

                    @Override
                    public void onWrite(PageRange[] pages, ParcelFileDescriptor dest, CancellationSignal cs, WriteResultCallback cb) {
                        try (OutputStream out = new FileOutputStream(dest.getFileDescriptor())) {
                            out.write(bytes);
                            cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
                        } catch (Exception e) {
                            cb.onWriteFailed(String.valueOf(e.getMessage()));
                        }
                    }
                }, attrs);
                call.resolve();
            } catch (Exception e) {
                call.reject("print: " + e.getMessage());
            }
        });
    }

    @PluginMethod
    public void autoBackup(PluginCall call) {
        final byte[] bytes = Base64.decode(call.getString("data", ""), Base64.DEFAULT);
        final String name = call.getString("name", "Traffic-Auto.json");
        final int keep = call.getInt("keep", 14);
        if (bytes.length == 0) {
            call.reject("empty");
            return;
        }
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("unsupported");
            return;
        }
        ContentResolver cr = getContext().getContentResolver();
        Uri coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI;
        String rel = Environment.DIRECTORY_DOWNLOADS + "/Traffic/";
        try {
            Uri u = null;
            try (Cursor c = cr.query(coll, new String[]{MediaStore.MediaColumns._ID},
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + "=?",
                    new String[]{rel, name}, null)) {
                if (c != null && c.moveToFirst()) u = ContentUris.withAppendedId(coll, c.getLong(0));
            }
            if (u == null) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, rel);
                u = cr.insert(coll, v);
            }
            if (u == null) {
                call.reject("insert failed");
                return;
            }
            try (OutputStream o = cr.openOutputStream(u, "wt")) {
                o.write(bytes);
            }
            long sz;
            try (ParcelFileDescriptor p = cr.openFileDescriptor(u, "r")) {
                sz = p.getStatSize();
            }
            if (sz != bytes.length) {
                call.reject("size mismatch");
                return;
            }
            try (Cursor c = cr.query(coll, new String[]{MediaStore.MediaColumns._ID},
                    MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                    new String[]{rel, "Traffic-Auto-%"}, MediaStore.MediaColumns.DISPLAY_NAME + " DESC")) {
                int i = 0;
                while (c != null && c.moveToNext()) {
                    if (++i > keep) cr.delete(ContentUris.withAppendedId(coll, c.getLong(0)), null, null);
                }
            }
            JSObject res = new JSObject();
            res.put("size", sz);
            call.resolve(res);
        } catch (Exception e) {
            call.reject("auto: " + e.getMessage());
        }
    }

    @PluginMethod
    public void listBackups(PluginCall call) {
        if (Build.VERSION.SDK_INT < 29) {
            call.reject("unsupported");
            return;
        }
        ContentResolver cr = getContext().getContentResolver();
        JSArray arr = new JSArray();
        try (Cursor c = cr.query(MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                new String[]{MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE},
                MediaStore.MediaColumns.RELATIVE_PATH + "=? AND " + MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ?",
                new String[]{Environment.DIRECTORY_DOWNLOADS + "/Traffic/", "Traffic-%"},
                MediaStore.MediaColumns.DISPLAY_NAME + " DESC")) {
            while (c != null && c.moveToNext()) {
                JSObject o = new JSObject();
                o.put("id", c.getLong(0));
                o.put("name", c.getString(1));
                o.put("size", c.getLong(2));
                arr.put(o);
            }
        } catch (Exception e) {
            call.reject("list: " + e.getMessage());
            return;
        }
        JSObject res = new JSObject();
        res.put("items", arr);
        call.resolve(res);
    }

    @PluginMethod
    public void readBackup(PluginCall call) {
        try {
            Double d = call.getDouble("id");
            long id = d == null ? 0 : d.longValue();
            Uri u = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            try (InputStream in = getContext().getContentResolver().openInputStream(u)) {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            }
            JSObject res = new JSObject();
            res.put("text", new String(bo.toByteArray(), "UTF-8"));
            call.resolve(res);
        } catch (Exception e) {
            call.reject("read: " + e.getMessage());
        }
    }
}

package com.traffic.scanner;

import android.app.Activity;
import android.content.Intent;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "TrafficScanner")
public class TrafficScannerPlugin extends Plugin {

    @PluginMethod
    public void scan(PluginCall call) {
        Intent i = new Intent(getContext(), ScannerActivity.class);
        startActivityForResult(call, i, "onScanResult");
    }

    @ActivityCallback
    private void onScanResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        Intent d = result.getData();
        if (result.getResultCode() == Activity.RESULT_OK && d != null) {
            JSObject o = new JSObject();
            o.put("value", d.getStringExtra("value"));
            o.put("format", d.getStringExtra("format"));
            call.resolve(o);
        } else {
            call.reject("canceled");
        }
    }
}

package com.traffic.scanner;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.ReaderException;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScannerActivity extends AppCompatActivity {
    private static final int REQ = 4411;
    private final MultiFormatReader reader = new MultiFormatReader();
    private ExecutorService exec;
    private PreviewView previewView;
    private FrameLayout root;
    private Camera camera;
    private volatile boolean done = false;
    private String last = "";
    private long lastT = 0;
    private int frame = 0;
    private byte[] yBuf, rBuf, tBuf;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Map<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);
        hints.put(DecodeHintType.POSSIBLE_FORMATS, Arrays.asList(
                BarcodeFormat.EAN_13, BarcodeFormat.EAN_8, BarcodeFormat.UPC_A, BarcodeFormat.UPC_E,
                BarcodeFormat.CODE_128, BarcodeFormat.CODE_39, BarcodeFormat.CODE_93, BarcodeFormat.ITF,
                BarcodeFormat.CODABAR, BarcodeFormat.QR_CODE, BarcodeFormat.DATA_MATRIX));
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        reader.setHints(hints);
        exec = Executors.newSingleThreadExecutor();

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        previewView = new PreviewView(this);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new Finder(this), new FrameLayout.LayoutParams(-1, -1));

        TextView tv = new TextView(this);
        tv.setText("بارکد را داخل کادر قرار دهید");
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(16);
        tv.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        tp.bottomMargin = dp(120);
        root.addView(tv, tp);

        Button close = new Button(this);
        close.setText("✕");
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(56), dp(56), Gravity.TOP | Gravity.END);
        cp.topMargin = dp(16);
        cp.rightMargin = dp(16);
        root.addView(close, cp);
        setContentView(root);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            start();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ);
        }
    }

    @Override
    public void onRequestPermissionsResult(int rc, @NonNull String[] p, @NonNull int[] g) {
        super.onRequestPermissionsResult(rc, p, g);
        if (rc == REQ && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) {
            start();
        } else {
            Toast.makeText(this, "برای اسکن بارکد، دسترسی دوربین لازم است.", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    private void start() {
        final ListenableFuture<ProcessCameraProvider> f = ProcessCameraProvider.getInstance(this);
        f.addListener(() -> {
            try {
                ProcessCameraProvider p = f.get();
                Preview pv = new Preview.Builder().build();
                pv.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis ia = new ImageAnalysis.Builder()
                        .setResolutionSelector(new ResolutionSelector.Builder()
                                .setResolutionStrategy(new ResolutionStrategy(new Size(1920, 1080),
                                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                                .build())
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                ia.setAnalyzer(exec, this::analyze);
                p.unbindAll();
                camera = p.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, pv, ia);
                if (camera.getCameraInfo().hasFlashUnit()) addTorch();
            } catch (Exception e) {
                Toast.makeText(this, "خطا در باز کردن دوربین", Toast.LENGTH_LONG).show();
                finish();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void addTorch() {
        final Button tb = new Button(this);
        tb.setText("🔦");
        tb.setTextSize(22);
        tb.setAlpha(0.6f);
        final boolean[] on = {false};
        tb.setOnClickListener(v -> {
            on[0] = !on[0];
            camera.getCameraControl().enableTorch(on[0]);
            tb.setAlpha(on[0] ? 1f : 0.6f);
        });
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(dp(68), dp(68), Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(40);
        root.addView(tb, lp);
    }

    private void analyze(ImageProxy img) {
        try {
            if (done) return;
            ImageProxy.PlaneProxy pl = img.getPlanes()[0];
            ByteBuffer buf = pl.getBuffer();
            int rs = pl.getRowStride();
            int w = img.getWidth();
            int h = img.getHeight();
            int rot = img.getImageInfo().getRotationDegrees();
            if (yBuf == null || yBuf.length != w * h) {
                yBuf = new byte[w * h];
                rBuf = new byte[w * h];
                tBuf = new byte[w * h];
            }
            for (int r = 0; r < h; r++) {
                buf.position(r * rs);
                buf.get(yBuf, r * w, w);
            }
            byte[] src = yBuf;
            int sw = w, sh = h;
            if (rot == 90 || rot == 270) {
                rotate(yBuf, rBuf, w, h, rot);
                src = rBuf;
                sw = h;
                sh = w;
            } else if (rot == 180) {
                int n = w * h;
                for (int i = 0; i < n; i++) rBuf[i] = yBuf[n - 1 - i];
                src = rBuf;
            }
            Result res = decode(src, sw, sh);
            if (res == null && (frame++ % 3 == 2)) {
                rotate(src, tBuf, sw, sh, 90);
                res = decode(tBuf, sh, sw);
            }
            if (res != null && res.getText() != null && !res.getText().isEmpty()) {
                String v = res.getText();
                long now = System.currentTimeMillis();
                if (v.equals(last) && now - lastT < 1500) {
                    finishWith(v, res.getBarcodeFormat().name());
                } else {
                    last = v;
                    lastT = now;
                }
            }
        } catch (Exception ignored) {
        } finally {
            img.close();
        }
    }

    private Result decode(byte[] d, int dw, int dh) {
        int l = (int) (dw * 0.05), t = (int) (dh * 0.2), cw = dw - 2 * l, ch = (int) (dh * 0.6);
        try {
            PlanarYUVLuminanceSource s = new PlanarYUVLuminanceSource(d, dw, dh, l, t, cw, ch, false);
            return reader.decodeWithState(new BinaryBitmap(new HybridBinarizer(s)));
        } catch (ReaderException e) {
            return null;
        } finally {
            reader.reset();
        }
    }

    private static void rotate(byte[] s, byte[] d, int w, int h, int rot) {
        if (rot == 90) {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) d[x * h + (h - 1 - y)] = s[ro + x];
            }
        } else {
            for (int y = 0; y < h; y++) {
                int ro = y * w;
                for (int x = 0; x < w; x++) d[(w - 1 - x) * h + y] = s[ro + x];
            }
        }
    }

    private void finishWith(final String v, final String fmt) {
        done = true;
        runOnUiThread(() -> {
            vibrate();
            Intent d = new Intent();
            d.putExtra("value", v);
            d.putExtra("format", fmt);
            setResult(RESULT_OK, d);
            finish();
        });
    }

    @SuppressWarnings("deprecation")
    private void vibrate() {
        try {
            Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vb == null) return;
            if (Build.VERSION.SDK_INT >= 26) {
                vb.vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vb.vibrate(80);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        exec.shutdown();
    }

    static class Finder extends View {
        private final Paint dim = new Paint(), line = new Paint(), box = new Paint();

        Finder(Context c) {
            super(c);
            dim.setColor(0x99000000);
            line.setColor(0xFFFF3B30);
            line.setStrokeWidth(4f);
            box.setColor(Color.WHITE);
            box.setStyle(Paint.Style.STROKE);
            box.setStrokeWidth(6f);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth(), h = getHeight();
            float bw = w * 0.84f, bh = h * 0.28f;
            float l = (w - bw) / 2f, t = (h - bh) / 2f - h * 0.04f, r = l + bw, b = t + bh;
            c.drawRect(0, 0, w, t, dim);
            c.drawRect(0, b, w, h, dim);
            c.drawRect(0, t, l, b, dim);
            c.drawRect(r, t, w, b, dim);
            c.drawRect(l, t, r, b, box);
            c.drawLine(l + 10, (t + b) / 2f, r - 10, (t + b) / 2f, line);
        }
    }
}

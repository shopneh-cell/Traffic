package com.traffic.scanner;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.util.Size;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.FocusMeteringAction;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.MeteringPoint;
import androidx.camera.core.Preview;
import androidx.camera.core.ZoomState;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.resolutionselector.ResolutionStrategy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * صفحه‌ی «اسکن بارکد». دوربین با CameraX و تشخیص با ZXing، هر دو داخل برنامه.
 * نتیجه با extra های value و format به فراخواننده برمی‌گردد.
 */
public class ScannerActivity extends AppCompatActivity {
    private static final int REQ_CAMERA = 4411;
    private static final float[] ZOOMS = {1f, 2f, 3f};

    private ExecutorService exec;
    private ProcessCameraProvider provider;
    private Camera camera;
    private BarcodeAnalyzer analyzer;
    private ToneGenerator tone;

    private FrameLayout root;
    private PreviewView previewView;
    private TextView hint;
    private TextView errorView;
    private LinearLayout resultCard;
    private TextView valueView;
    private TextView formatView;
    private Button zoomBtn;
    private Button torchBtn;

    private int zoomIdx = 0;
    private float maxZoom = 1f;
    private boolean torchOn = false;
    private boolean resultShown = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        exec = Executors.newSingleThreadExecutor();
        try {
            tone = new ToneGenerator(AudioManager.STREAM_MUSIC, 80);
        } catch (RuntimeException ignored) {
            tone = null;
        }
        buildUi();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
        }
    }

    private void buildUi() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FILL_CENTER);
        root.addView(previewView, new FrameLayout.LayoutParams(-1, -1));
        root.addView(new Finder(this), new FrameLayout.LayoutParams(-1, -1));

        // نوار بالا: دکمه‌ی بازگشت و عنوان
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(0xB3000000);
        top.setPadding(dp(8), dp(10), dp(12), dp(10));
        Button back = styledButton("بازگشت");
        back.setOnClickListener(v -> cancel());
        top.addView(back, new LinearLayout.LayoutParams(-2, -2));
        TextView title = new TextView(this);
        title.setText("اسکن بارکد");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        top.addView(title, new LinearLayout.LayoutParams(0, -2, 1f));
        View spacer = new View(this);
        top.addView(spacer, new LinearLayout.LayoutParams(dp(78), 1));
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // پیام خطای دسترسی دوربین (پیش‌فرض پنهان)
        errorView = new TextView(this);
        errorView.setTextColor(Color.WHITE);
        errorView.setTextSize(17);
        errorView.setGravity(Gravity.CENTER);
        errorView.setPadding(dp(24), dp(24), dp(24), dp(24));
        errorView.setVisibility(View.GONE);
        root.addView(errorView, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        // پایین صفحه: راهنما یا کارت نتیجه، و کنترل‌ها
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(dp(16), 0, dp(16), dp(28));

        hint = new TextView(this);
        hint.setText("بارکد را داخل کادر قرار دهید");
        hint.setTextColor(Color.WHITE);
        hint.setTextSize(16);
        hint.setGravity(Gravity.CENTER);
        bottom.addView(hint, new LinearLayout.LayoutParams(-1, -2));

        resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setGravity(Gravity.CENTER_HORIZONTAL);
        resultCard.setPadding(dp(18), dp(16), dp(18), dp(16));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(0xF0202020);
        cardBg.setCornerRadius(dp(18));
        resultCard.setBackground(cardBg);
        resultCard.setVisibility(View.GONE);

        valueView = new TextView(this);
        valueView.setTextColor(Color.WHITE);
        valueView.setTextSize(24);
        valueView.setGravity(Gravity.CENTER);
        valueView.setTextIsSelectable(true);
        resultCard.addView(valueView, new LinearLayout.LayoutParams(-1, -2));

        formatView = new TextView(this);
        formatView.setTextColor(0xFFBBBBBB);
        formatView.setTextSize(13);
        formatView.setGravity(Gravity.CENTER);
        resultCard.addView(formatView, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        Button again = styledButton("اسکن مجدد");
        again.setOnClickListener(v -> scanAgain());
        Button use = styledButton("استفاده");
        use.setBackgroundColor(0xFF2E7D32);
        use.setOnClickListener(v -> useResult());
        actions.addView(again, new LinearLayout.LayoutParams(0, -2, 1f));
        actions.addView(use, new LinearLayout.LayoutParams(0, -2, 1f));
        resultCard.addView(actions, new LinearLayout.LayoutParams(-1, -2));
        bottom.addView(resultCard, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        zoomBtn = styledButton("2×");
        zoomBtn.setOnClickListener(v -> cycleZoom());
        torchBtn = styledButton("🔦");
        torchBtn.setAlpha(0.6f);
        torchBtn.setVisibility(View.GONE);
        torchBtn.setOnClickListener(v -> toggleTorch());
        controls.addView(zoomBtn, new LinearLayout.LayoutParams(-2, -2));
        controls.addView(torchBtn, new LinearLayout.LayoutParams(-2, -2));
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(-2, -2);
        gap.leftMargin = dp(16);
        torchBtn.setLayoutParams(gap);
        bottom.addView(controls, new LinearLayout.LayoutParams(-1, -2));

        root.addView(bottom, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
    }

    private Button styledButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(0xCC37474F);
        return b;
    }

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                provider = future.get();
                Preview preview = new Preview.Builder().build();
                preview.setSurfaceProvider(previewView.getSurfaceProvider());
                ImageAnalysis ia = new ImageAnalysis.Builder()
                        .setResolutionSelector(new ResolutionSelector.Builder()
                                .setResolutionStrategy(new ResolutionStrategy(new Size(1920, 1080),
                                        ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER))
                                .build())
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build();
                analyzer = new BarcodeAnalyzer((value, format) -> runOnUiThread(() -> onFound(value, format)));
                ia.setAnalyzer(exec, analyzer);
                provider.unbindAll();
                camera = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, ia);
                setupCameraControls();
            } catch (Exception e) {
                showError("دوربین باز نشد. دوباره تلاش کنید.");
            }
        }, ContextCompat.getMainExecutor(this));
    }

    private void setupCameraControls() {
        maxZoom = 1f;
        ZoomState zs = camera.getCameraInfo().getZoomState().getValue();
        if (zs != null) {
            maxZoom = zs.getMaxZoomRatio();
        }
        // پیش‌فرض ۲× برای بارکدهای ریز؛ اگر دوربین زوم نداشت، ۱×
        zoomIdx = maxZoom >= 2f ? 1 : 0;
        applyZoom();
        torchBtn.setVisibility(camera.getCameraInfo().hasFlashUnit() ? View.VISIBLE : View.GONE);
        previewView.post(this::focusCenter);
    }

    private void applyZoom() {
        float z = Math.min(ZOOMS[zoomIdx], maxZoom);
        camera.getCameraControl().setZoomRatio(z);
        zoomBtn.setText(z == Math.floor(z) ? (int) z + "×" : String.format(Locale.US, "%.1f×", z));
    }

    private void cycleZoom() {
        if (camera == null) {
            return;
        }
        zoomIdx = (zoomIdx + 1) % ZOOMS.length;
        applyZoom();
    }

    /** فوکوس و نوردهی روی مرکز کادر، برای بارکد ریز که وسط تصویر است. */
    private void focusCenter() {
        try {
            MeteringPoint point = previewView.getMeteringPointFactory().createPoint(0.5f, 0.5f);
            FocusMeteringAction action = new FocusMeteringAction.Builder(point,
                    FocusMeteringAction.FLAG_AF | FocusMeteringAction.FLAG_AE)
                    .setAutoCancelDuration(3, TimeUnit.SECONDS)
                    .build();
            camera.getCameraControl().startFocusAndMetering(action);
        } catch (Exception ignored) {
            // فوکوس دستی اختیاری است؛ خطای آن نباید اسکن را متوقف کند
        }
    }

    private void toggleTorch() {
        if (camera == null) {
            return;
        }
        torchOn = !torchOn;
        camera.getCameraControl().enableTorch(torchOn);
        torchBtn.setAlpha(torchOn ? 1f : 0.6f);
    }

    @Override
    public void onRequestPermissionsResult(int code, @NonNull String[] permissions, @NonNull int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code == REQ_CAMERA && grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
            startCamera();
        } else {
            showError("برای اسکن بارکد، دسترسی دوربین لازم است.");
        }
    }

    private void showError(String message) {
        errorView.setText(message);
        errorView.setVisibility(View.VISIBLE);
        hint.setVisibility(View.GONE);
    }

    private void onFound(String value, String format) {
        if (resultShown) {
            return;
        }
        resultShown = true;
        if (analyzer != null) {
            analyzer.setPaused(true);
        }
        beep();
        valueView.setText(value);
        formatView.setText(format);
        hint.setVisibility(View.GONE);
        resultCard.setVisibility(View.VISIBLE);
    }

    private void scanAgain() {
        resultShown = false;
        resultCard.setVisibility(View.GONE);
        hint.setVisibility(View.VISIBLE);
        if (analyzer != null) {
            analyzer.setPaused(false);
        }
    }

    private void useResult() {
        Intent data = new Intent();
        data.putExtra("value", valueView.getText().toString());
        data.putExtra("format", formatView.getText().toString());
        setResult(RESULT_OK, data);
        finish();
    }

    private void cancel() {
        setResult(RESULT_CANCELED);
        finish();
    }

    private void beep() {
        try {
            if (tone != null) {
                tone.startTone(ToneGenerator.TONE_PROP_BEEP, 120);
            }
        } catch (Exception ignored) {
            // صدا اختیاری است
        }
        vibrate(60);
    }

    @SuppressWarnings("deprecation")
    private void vibrate(int millis) {
        try {
            Vibrator vb = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vb == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                vb.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE));
            } else {
                vb.vibrate(millis);
            }
        } catch (Exception ignored) {
            // ویبره اختیاری است
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (provider != null) {
            provider.unbindAll();
        }
        if (exec != null) {
            exec.shutdown();
        }
        if (tone != null) {
            tone.release();
        }
    }

    /** پوشش تیره با کادر سفید و خط قرمز وسط، فقط برای راهنمایی چشمی. */
    static class Finder extends View {
        private final Paint dim = new Paint();
        private final Paint line = new Paint();
        private final Paint box = new Paint();

        Finder(Context c) {
            super(c);
            dim.setColor(0x99000000);
            line.setColor(0xFFFF3B30);
            line.setStrokeWidth(4f);
            box.setColor(Color.WHITE);
            box.setStyle(Paint.Style.STROKE);
            box.setStrokeWidth(6f);
        }

        @Override
        protected void onDraw(Canvas c) {
            int w = getWidth();
            int h = getHeight();
            float bw = w * 0.84f;
            float bh = h * 0.28f;
            float l = (w - bw) / 2f;
            float t = (h - bh) / 2f - h * 0.04f;
            float r = l + bw;
            float b = t + bh;
            c.drawRect(0, 0, w, t, dim);
            c.drawRect(0, b, w, h, dim);
            c.drawRect(0, t, l, b, dim);
            c.drawRect(r, t, w, b, dim);
            c.drawRect(l, t, r, b, box);
            c.drawLine(l + 10, (t + b) / 2f, r - 10, (t + b) / 2f, line);
        }
    }
}
